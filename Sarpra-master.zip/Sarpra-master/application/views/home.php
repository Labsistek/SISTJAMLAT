<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <style>
      h1{
        text-align:center;
      }
    </style>
  </head>
  <body>
  <h1>Mudah Bersama SarPra</h1>
  </body> 
</html>
